import json
import os
import re
import sqlite3
import time

BOOKS = [
    (1, 'GEN', 'Genesis', 'Mwanzo', 'Gen', 'Mwa', 'OT', 50, 'Law'),
    (2, 'EXO', 'Exodus', 'Kutoka', 'Exo', 'Kut', 'OT', 40, 'Law'),
    (3, 'LEV', 'Leviticus', 'Mambo ya Walawi', 'Lev', 'Law', 'OT', 27, 'Law'),
    (4, 'NUM', 'Numbers', 'Hesabu', 'Num', 'Hes', 'OT', 36, 'Law'),
    (5, 'DEU', 'Deuteronomy', 'Kumbukumbu la Torati', 'Deu', 'Kum', 'OT', 34, 'Law'),
    (6, 'JOS', 'Joshua', 'Yoshua', 'Jos', 'Yos', 'OT', 24, 'History'),
    (7, 'JDG', 'Judges', 'Waamuzi', 'Jdg', 'Waa', 'OT', 21, 'History'),
    (8, 'RUT', 'Ruth', 'Ruthi', 'Rut', 'Rut', 'OT', 4, 'History'),
    (9, '1SA', '1 Samuel', '1 Samweli', '1Sa', '1Sam', 'OT', 31, 'History'),
    (10, '2SA', '2 Samuel', '2 Samweli', '2Sa', '2Sam', 'OT', 24, 'History'),
    (11, '1KI', '1 Kings', '1 Wafalme', '1Ki', '1Waf', 'OT', 22, 'History'),
    (12, '2KI', '2 Kings', '2 Wafalme', '2Ki', '2Waf', 'OT', 25, 'History'),
    (13, '1CH', '1 Chronicles', '1 Mambo ya Nyakati', '1Ch', '1Nya', 'OT', 29, 'History'),
    (14, '2CH', '2 Chronicles', '2 Mambo ya Nyakati', '2Ch', '2Nya', 'OT', 36, 'History'),
    (15, 'EZR', 'Ezra', 'Ezra', 'Ezr', 'Ezr', 'OT', 10, 'History'),
    (16, 'NEH', 'Nehemiah', 'Nehemia', 'Neh', 'Neh', 'OT', 13, 'History'),
    (17, 'EST', 'Esther', 'Esta', 'Est', 'Est', 'OT', 10, 'History'),
    (18, 'JOB', 'Job', 'Ayubu', 'Job', 'Ayu', 'OT', 42, 'Poetry'),
    (19, 'PSA', 'Psalms', 'Zaburi', 'Psa', 'Zab', 'OT', 150, 'Poetry'),
    (20, 'PRO', 'Proverbs', 'Mithali', 'Pro', 'Mit', 'OT', 31, 'Poetry'),
    (21, 'ECC', 'Ecclesiastes', 'Mhubiri', 'Ecc', 'Mhu', 'OT', 12, 'Poetry'),
    (22, 'SNG', 'Song of Solomon', 'Wimbo Ulio Bora', 'Sng', 'Wim', 'OT', 8, 'Poetry'),
    (23, 'ISA', 'Isaiah', 'Isaya', 'Isa', 'Isa', 'OT', 66, 'Prophets'),
    (24, 'JER', 'Jeremiah', 'Yeremia', 'Jer', 'Yer', 'OT', 52, 'Prophets'),
    (25, 'LAM', 'Lamentations', 'Maombolezo', 'Lam', 'Mao', 'OT', 5, 'Prophets'),
    (26, 'EZK', 'Ezekiel', 'Ezekieli', 'Ezk', 'Eze', 'OT', 48, 'Prophets'),
    (27, 'DAN', 'Daniel', 'Danieli', 'Dan', 'Dan', 'OT', 12, 'Prophets'),
    (28, 'HOS', 'Hosea', 'Hosea', 'Hos', 'Hos', 'OT', 14, 'Prophets'),
    (29, 'JOL', 'Joel', 'Yoeli', 'Jol', 'Yoe', 'OT', 3, 'Prophets'),
    (30, 'AMO', 'Amos', 'Amosi', 'Amo', 'Amo', 'OT', 9, 'Prophets'),
    (31, 'OBA', 'Obadiah', 'Obadia', 'Oba', 'Oba', 'OT', 1, 'Prophets'),
    (32, 'JON', 'Jonah', 'Yona', 'Jon', 'Yon', 'OT', 4, 'Prophets'),
    (33, 'MIC', 'Micah', 'Mika', 'Mic', 'Mik', 'OT', 7, 'Prophets'),
    (34, 'NAM', 'Nahum', 'Nahumu', 'Nam', 'Nah', 'OT', 3, 'Prophets'),
    (35, 'HAB', 'Habakkuk', 'Habakuki', 'Hab', 'Hab', 'OT', 3, 'Prophets'),
    (36, 'ZEP', 'Zephaniah', 'Sefania', 'Zep', 'Sef', 'OT', 3, 'Prophets'),
    (37, 'HAG', 'Haggai', 'Hagai', 'Hag', 'Hag', 'OT', 2, 'Prophets'),
    (38, 'ZEC', 'Zechariah', 'Zekaria', 'Zec', 'Zek', 'OT', 14, 'Prophets'),
    (39, 'MAL', 'Malachi', 'Malaki', 'Mal', 'Mal', 'OT', 4, 'Prophets'),
    (40, 'MAT', 'Matthew', 'Mathayo', 'Mat', 'Mat', 'NT', 28, 'Gospels'),
    (41, 'MRK', 'Mark', 'Marko', 'Mrk', 'Mar', 'NT', 16, 'Gospels'),
    (42, 'LUK', 'Luke', 'Luka', 'Luk', 'Luk', 'NT', 24, 'Gospels'),
    (43, 'JHN', 'John', 'Yohana', 'Jhn', 'Yoh', 'NT', 21, 'Gospels'),
    (44, 'ACT', 'Acts', 'Matendo ya Mitume', 'Act', 'Mdo', 'NT', 28, 'History'),
    (45, 'ROM', 'Romans', 'Warumi', 'Rom', 'Rum', 'NT', 16, 'Epistles'),
    (46, '1CO', '1 Corinthians', '1 Wakorintho', '1Co', '1Kor', 'NT', 16, 'Epistles'),
    (47, '2CO', '2 Corinthians', '2 Wakorintho', '2Co', '2Kor', 'NT', 13, 'Epistles'),
    (48, 'GAL', 'Galatians', 'Wagalatia', 'Gal', 'Gal', 'NT', 6, 'Epistles'),
    (49, 'EPH', 'Ephesians', 'Waefeso', 'Eph', 'Efe', 'NT', 6, 'Epistles'),
    (50, 'PHP', 'Philippians', 'Wafilipi', 'Php', 'Fil', 'NT', 4, 'Epistles'),
    (51, 'COL', 'Colossians', 'Wakolosai', 'Col', 'Kol', 'NT', 4, 'Epistles'),
    (52, '1TH', '1 Thessalonians', '1 Wathesalonike', '1Th', '1The', 'NT', 5, 'Epistles'),
    (53, '2TH', '2 Thessalonians', '2 Wathesalonike', '2Th', '2The', 'NT', 3, 'Epistles'),
    (54, '1TI', '1 Timothy', '1 Timotheo', '1Ti', '1Tim', 'NT', 6, 'Epistles'),
    (55, '2TI', '2 Timothy', '2 Timotheo', '2Ti', '2Tim', 'NT', 4, 'Epistles'),
    (56, 'TIT', 'Titus', 'Tito', 'Tit', 'Tit', 'NT', 3, 'Epistles'),
    (57, 'PHM', 'Philemon', 'Filemoni', 'Phm', 'Flm', 'NT', 1, 'Epistles'),
    (58, 'HEB', 'Hebrews', 'Waebrania', 'Heb', 'Ebr', 'NT', 13, 'Epistles'),
    (59, 'JAS', 'James', 'Yakobo', 'Jas', 'Yak', 'NT', 5, 'Epistles'),
    (60, '1PE', '1 Peter', '1 Petro', '1Pe', '1Pet', 'NT', 5, 'Epistles'),
    (61, '2PE', '2 Peter', '2 Petro', '2Pe', '2Pet', 'NT', 3, 'Epistles'),
    (62, '1JN', '1 John', '1 Yohana', '1Jn', '1Yoh', 'NT', 5, 'Epistles'),
    (63, '2JN', '2 John', '2 Yohana', '2Jn', '2Yoh', 'NT', 1, 'Epistles'),
    (64, '3JN', '3 John', '3 Yohana', '3Jn', '3Yoh', 'NT', 1, 'Epistles'),
    (65, 'JUD', 'Jude', 'Yuda', 'Jud', 'Yud', 'NT', 1, 'Epistles'),
    (66, 'REV', 'Revelation', 'Ufunuo wa Yohana', 'Rev', 'Ufu', 'NT', 22, 'Apocalypse'),
]

BOOK_NAME_TO_ID = {b[2].lower(): b[1] for b in BOOKS}
BOOK_NAME_TO_ID['psalm'] = 'PSA'


def parse_helloao_content(content_list):
    plain_parts = []
    tagged_parts = []
    has_jesus = False

    for item in content_list:
        if isinstance(item, str):
            text = item.replace('¶', '').strip()
            if text:
                plain_parts.append(text)
                tagged_parts.append(text)
        elif isinstance(item, dict):
            if 'noteId' in item or item.get('lineBreak'):
                continue
            text = (item.get('text') or '').replace('¶', '').strip()
            if not text:
                continue
            plain_parts.append(text)
            if item.get('wordsOfJesus'):
                has_jesus = True
                tagged_parts.append(f'[J]{text}[/J]')
            else:
                tagged_parts.append(text)

    plain = re.sub(r'\s+', ' ', ' '.join(plain_parts)).strip()
    tagged = re.sub(r'\s+', ' ', ' '.join(tagged_parts)).strip()
    tagged = tagged.replace('[/J] [J]', ' ')
    return plain, (tagged if has_jesus else None), has_jesus


def load_verified_overrides():
    import subprocess
    js_script = """
    import { VERIFIED_SCRIPTURES } from './src/data/bibleData.ts';
    console.log(JSON.stringify(VERIFIED_SCRIPTURES));
    """
    res = subprocess.run(
        ['npx', 'tsx', '-e', js_script],
        cwd='/app/applet',
        capture_output=True,
        text=True,
        check=True
    )
    items = json.loads(res.stdout)
    overrides = {}
    for v in items:
        bid = BOOK_NAME_TO_ID.get(v['book'].lower())
        if not bid:
            continue
        key = (bid, int(v['chapter']), int(v['verse']))
        en_text = v['enText'].strip()
        sw_text = v['swText'].strip()
        is_jesus = bool(v.get('isJesusWords', False))

        if 'segmentsEn' in v and v['segmentsEn']:
            en_tagged = ''.join(f"[J]{s['text']}[/J]" if s.get('isJesus') else s['text'] for s in v['segmentsEn'])
        elif is_jesus:
            en_tagged = f"[J]{en_text}[/J]"
        else:
            en_tagged = None

        if 'segmentsSw' in v and v['segmentsSw']:
            sw_tagged = ''.join(f"[J]{s['text']}[/J]" if s.get('isJesus') else s['text'] for s in v['segmentsSw'])
        elif is_jesus:
            sw_tagged = f"[J]{sw_text}[/J]"
        else:
            sw_tagged = None

        overrides[key] = (en_text, sw_text, en_tagged, sw_tagged, 1 if is_jesus else 0)
    return overrides


def build_database(output_db_path):
    with open('/tmp/eng_kjv.json', 'r', encoding='utf-8') as f:
        en_data = json.load(f)
    with open('/tmp/swh_bib.json', 'r', encoding='utf-8') as f:
        sw_data = json.load(f)

    en_map = {}
    for b in en_data['books']:
        bid = b['id']
        for ch in b['chapters']:
            cnum = int(ch['chapter']['number'])
            for item in ch['chapter']['content']:
                if item.get('type') == 'verse':
                    vnum = int(item['number'])
                    plain, tagged, has_j = parse_helloao_content(item.get('content', []))
                    en_map[(bid, cnum, vnum)] = (plain, tagged, has_j)

    sw_map = {}
    for b in sw_data['books']:
        bid = b['id']
        for ch in b['chapters']:
            cnum = int(ch['chapter']['number'])
            for item in ch['chapter']['content']:
                if item.get('type') == 'verse':
                    vnum = int(item['number'])
                    plain, tagged, has_j = parse_helloao_content(item.get('content', []))
                    sw_map[(bid, cnum, vnum)] = (plain, tagged, has_j)

    overrides = load_verified_overrides()
    print(f"Loaded {len(overrides)} verified NKJV+SUV override verses.")

    if os.path.exists(output_db_path):
        os.remove(output_db_path)

    conn = sqlite3.connect(output_db_path)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE books (
            book_order INTEGER PRIMARY KEY,
            id TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            sw_name TEXT NOT NULL,
            abbrev TEXT NOT NULL,
            sw_abbrev TEXT NOT NULL,
            testament TEXT NOT NULL,
            chapters_count INTEGER NOT NULL,
            category TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE verses (
            book_id TEXT NOT NULL,
            chapter INTEGER NOT NULL,
            verse INTEGER NOT NULL,
            en_text TEXT NOT NULL,
            sw_text TEXT NOT NULL,
            en_tagged TEXT,
            sw_tagged TEXT,
            is_jesus_words INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (book_id, chapter, verse)
        )
    """)

    cur.execute("CREATE INDEX idx_verses_book_chapter ON verses(book_id, chapter)")

    cur.executemany(
        "INSERT INTO books VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        BOOKS
    )

    all_keys = sorted(
        set(en_map.keys()) | set(sw_map.keys()) | set(overrides.keys()),
        key=lambda k: (next(b[0] for b in BOOKS if b[1] == k[0]), k[1], k[2])
    )

    rows = []
    for key in all_keys:
        bid, ch, v = key
        if key in overrides:
            en_text, sw_text, en_tagged, sw_tagged, is_j = overrides[key]
        else:
            en_plain, en_tag, en_j = en_map.get(key, ('', None, False))
            sw_plain, sw_tag, sw_j = sw_map.get(key, ('', None, False))
            en_text = en_plain
            sw_text = sw_plain
            en_tagged = en_tag
            sw_tagged = sw_tag
            is_j = 1 if (en_j or sw_j) else 0

        if not en_text and not sw_text:
            continue

        rows.append((bid, ch, v, en_text, sw_text, en_tagged, sw_tagged, is_j))

    cur.executemany("INSERT INTO verses VALUES (?, ?, ?, ?, ?, ?, ?, ?)", rows)
    conn.commit()
    cur.execute("VACUUM")

    # Quick audit & benchmark
    t0 = time.time()
    search_hits = cur.execute(
        "SELECT book_id, chapter, verse, en_text, sw_text FROM verses WHERE en_text LIKE '%everlasting life%' OR sw_text LIKE '%uzima wa milele%' LIMIT 50"
    ).fetchall()
    dt_ms = (time.time() - t0) * 1000
    print(f"Search benchmark ('everlasting life' / 'uzima wa milele'): {len(search_hits)} hits in {dt_ms:.1f} ms")

    book_count = cur.execute("SELECT COUNT(*) FROM books").fetchone()[0]
    chap_count = cur.execute("SELECT COUNT(DISTINCT book_id || '_' || chapter) FROM verses").fetchone()[0]
    missing_en = cur.execute("SELECT COUNT(*) FROM verses WHERE en_text = ''").fetchone()[0]
    missing_sw = cur.execute("SELECT COUNT(*) FROM verses WHERE sw_text = ''").fetchone()[0]
    conn.close()

    size_mb = os.path.getsize(output_db_path) / (1024 * 1024)
    print(f"Built SQLite database at {output_db_path}:")
    print(f"  Books: {book_count}, Chapters: {chap_count}, Verses: {len(rows)}")
    print(f"  Missing EN: {missing_en}, Missing SW: {missing_sw}")
    print(f"  DB File Size: {size_mb:.2f} MB")


if __name__ == '__main__':
    os.makedirs('/tmp/android_assets', exist_ok=True)
    build_database('/tmp/android_assets/bible.db')
