import { BIBLE_BOOKS } from '../src/data/bibleBooks';
import { VERIFIED_SCRIPTURES } from '../src/data/bibleData';
import { MATTHEW_COMPLETE_SCRIPTURES } from '../src/data/matthewScriptures';
import { createVerseId, alignChapterVerses } from '../src/utils/verseAlignment';

interface BookReport {
  id: string;
  name: string;
  swName: string;
  testament: 'OT' | 'NT';
  totalChapters: number;
  inMemoryChapters: number[];
  inMemoryVersesCount: number;
  allVerses1to1Matched: boolean;
  offlineDownloadSupport: boolean;
}

export function runFullBibleAudit() {
  const booksReport: BookReport[] = [];
  let totalVersesInMemory = 0;
  let totalOtVerses = 0;
  let totalNtVerses = 0;
  let totalOtChapters = 0;
  let totalNtChapters = 0;

  for (const book of BIBLE_BOOKS) {
    if (book.testament === 'OT') {
      totalOtChapters += book.chaptersCount;
    } else {
      totalNtChapters += book.chaptersCount;
    }

    // Filter in-memory verses for this book
    const bookVerses = VERIFIED_SCRIPTURES.filter(
      (v) => v.book.toLowerCase() === book.name.toLowerCase()
    );

    const chapterSet = new Set<number>();
    let hasAlignmentDiscrepancy = false;

    for (const v of bookVerses) {
      chapterSet.add(v.chapter);
      // Check compound key
      const key = createVerseId(book.id, v.chapter, v.verse);
      if (!key.startsWith(`${book.id}_${v.chapter}_${v.verse}`)) {
        hasAlignmentDiscrepancy = true;
      }
    }

    const inMemoryChapters = Array.from(chapterSet).sort((a, b) => a - b);
    const inMemoryCount = bookVerses.length;
    totalVersesInMemory += inMemoryCount;

    if (book.testament === 'OT') {
      totalOtVerses += inMemoryCount;
    } else {
      totalNtVerses += inMemoryCount;
    }

    booksReport.push({
      id: book.id,
      name: book.name,
      swName: book.swName,
      testament: book.testament,
      totalChapters: book.chaptersCount,
      inMemoryChapters,
      inMemoryVersesCount: inMemoryCount,
      allVerses1to1Matched: !hasAlignmentDiscrepancy,
      offlineDownloadSupport: true,
    });
  }

  return {
    totalBooks: BIBLE_BOOKS.length,
    otBooks: BIBLE_BOOKS.filter((b) => b.testament === 'OT').length,
    ntBooks: BIBLE_BOOKS.filter((b) => b.testament === 'NT').length,
    totalChapters: totalOtChapters + totalNtChapters,
    totalOtChapters,
    totalNtChapters,
    totalVersesInMemory,
    totalOtVerses,
    totalNtVerses,
    booksReport,
  };
}

if (process.argv[1]?.endsWith('bibleFullAudit.ts')) {
  const audit = runFullBibleAudit();
  console.log('=== FULL BIBLE AUDIT SUMMARY ===');
  console.log(`Total Books: ${audit.totalBooks} (OT: ${audit.otBooks}, NT: ${audit.ntBooks})`);
  console.log(`Total Canonical Chapters: ${audit.totalChapters} (OT: ${audit.totalOtChapters}, NT: ${audit.totalNtChapters})`);
  console.log(`Curated In-Memory Verified Verses: ${audit.totalVersesInMemory}`);
  console.log('Sample In-Memory Books & Chapters:');
  for (const b of audit.booksReport.filter((b) => b.inMemoryVersesCount > 0)) {
    console.log(`- ${b.name} (${b.swName}): ${b.inMemoryVersesCount} verses across chapters [${b.inMemoryChapters.join(', ')}]`);
  }
}
