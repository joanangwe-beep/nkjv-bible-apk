import urllib.request
import zipfile
import io
import sys

def test_download(url):
    print(f"\n--- Testing Download from {url} ---")
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    
    with urllib.request.urlopen(req) as response:
        status = response.status
        content_type = response.headers.get('Content-Type')
        content_length = response.headers.get('Content-Length')
        content_disposition = response.headers.get('Content-Disposition')
        
        print(f"HTTP Status: {status}")
        print(f"Content-Type: {content_type}")
        print(f"Content-Length: {content_length} bytes")
        print(f"Content-Disposition: {content_disposition}")
        
        # Verify headers
        assert status == 200, f"Expected status 200, got {status}"
        assert content_type == 'application/zip', f"Expected application/zip, got {content_type}"
        assert int(content_length) > 10000000, f"Expected >10MB, got {content_length}"
        
        # Read entire payload
        body = response.read()
        downloaded_bytes = len(body)
        downloaded_mb = downloaded_bytes / (1024 * 1024)
        print(f"Downloaded payload: {downloaded_bytes} bytes ({downloaded_mb:.2f} MB)")
        assert downloaded_bytes == int(content_length), "Downloaded size does not match Content-Length"
        
        # Test ZIP integrity with zipfile
        zip_buffer = io.BytesIO(body)
        with zipfile.ZipFile(zip_buffer, 'r') as zf:
            bad_file = zf.testzip()
            if bad_file:
                print(f"FAILED: Corrupt file detected in zip: {bad_file}")
                sys.exit(1)
            file_names = zf.namelist()
            print(f"ZIP Archive verification passed! Total entries: {len(file_names)}")
            
            # Check essential Android files & workflow
            sample_expected = [
                '.github/workflows/build-apk.yml',
                'android/gradlew.bat',
                'android/gradlew',
                'android/variables.gradle',
                'android/build.gradle',
                'android/settings.gradle',
                'android/gradle/wrapper/gradle-wrapper.jar',
                'android/app/build.gradle',
                'android/app/src/main/AndroidManifest.xml',
                'android/app/src/main/assets/public/index.html',
                'dist/index.html',
                'capacitor.config.ts',
                'package.json',
                'README_WINDOWS_BUILD.md'
            ]
            for exp in sample_expected:
                assert exp in file_names, f"Missing expected file in zip: {exp}"
                print(f"  ✓ Found: {exp}")
            vars_text = zf.read('android/variables.gradle').decode('utf-8')
            assert 'minSdkVersion = 27' in vars_text, "minSdkVersion = 27 missing in android/variables.gradle"
            assert not any(n.startswith('android/app/src/main/assets/public/downloads') for n in file_names), "Unexpected downloads bloat inside APK assets"
                
    print(f"Download verification for {url} PASSED completely!\n")

if __name__ == '__main__':
    test_download('http://localhost:3000/api/download/android-project-zip')
    test_download('http://localhost:3000/downloads/nkjv-bible-android-project.zip')
