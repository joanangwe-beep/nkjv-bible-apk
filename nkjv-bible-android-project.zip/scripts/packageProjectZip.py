import os
import shutil
import zipfile


def create_project_zip():
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    downloads_dir = os.path.join(root_dir, 'downloads')
    os.makedirs(downloads_dir, exist_ok=True)

    # Ensure zero nested ZIP bloat exists inside public/, dist/, or android assets
    for stale_dir in [
        os.path.join(root_dir, 'public', 'downloads'),
        os.path.join(root_dir, 'dist', 'downloads'),
        os.path.join(root_dir, 'android', 'app', 'src', 'main', 'assets', 'public', 'downloads'),
    ]:
        if os.path.exists(stale_dir):
            shutil.rmtree(stale_dir)

    zip_path = os.path.join(downloads_dir, 'nkjv-bible-android-project.zip')

    exclude_dirs = {
        'node_modules',
        '.git',
        '.cache',
        'downloads',
        '__pycache__',
        '.temp',
        '.gradle',
        'build',
        'NKJV_BIBLE_ANDROID_NEW',
    }
    exclude_extensions = ('.zip', '.tar.gz', '.log', '.tmp')

    print(f"Creating pristine Capacitor Android project ZIP at: {zip_path}")

    file_count = 0
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipf:
        for walk_root, dirs, files in os.walk(root_dir):
            # Include .github/workflows explicitly, skip unwanted directories
            dirs[:] = sorted(
                d for d in dirs
                if d not in exclude_dirs and (not d.startswith('.') or d in {'.github', '.workflows'})
            )
            for file in sorted(files):
                if any(file.endswith(ext) for ext in exclude_extensions):
                    continue
                if file == '.env':
                    continue
                file_path = os.path.join(walk_root, file)
                rel_path = os.path.relpath(file_path, root_dir).replace(os.sep, '/')

                info = zipfile.ZipInfo.from_file(file_path, arcname=rel_path)
                if file == 'gradlew':
                    info.external_attr = (0o100755 & 0xFFFF) << 16
                else:
                    info.external_attr = (0o100644 & 0xFFFF) << 16

                with open(file_path, 'rb') as f:
                    zipf.writestr(info, f.read(), compress_type=zipfile.ZIP_DEFLATED)
                file_count += 1

    size_bytes = os.path.getsize(zip_path)
    size_mb = size_bytes / (1024 * 1024)
    print(f"Zip created successfully: {file_count} files, {size_bytes} bytes ({size_mb:.2f} MB)")

    with zipfile.ZipFile(zip_path, 'r') as testf:
        test_res = testf.testzip()
        if test_res is not None:
            raise RuntimeError(f"Corrupt file found in zip archive: {test_res}")
        namelist = testf.namelist()
        print(f"Integrity check passed! {len(namelist)} entries in archive.")

        required_items = [
            '.github/workflows/build-apk.yml',
            'android/gradlew.bat',
            'android/gradlew',
            'android/variables.gradle',
            'android/build.gradle',
            'android/settings.gradle',
            'android/gradle/wrapper/gradle-wrapper.jar',
            'android/app/build.gradle',
            'android/app/src/main/AndroidManifest.xml',
            'android/app/src/main/assets/public/index.html',
            'dist/index.html',
            'capacitor.config.ts',
            'package.json',
            'README_WINDOWS_BUILD.md',
        ]
        missing = [item for item in required_items if item not in namelist]
        if missing:
            raise RuntimeError(f"Archive missing critical files: {missing}")

        # Verify minSdkVersion = 27 inside archived variables.gradle
        vars_content = testf.read('android/variables.gradle').decode('utf-8')
        if 'minSdkVersion = 27' not in vars_content:
            raise RuntimeError("android/variables.gradle inside ZIP does not set minSdkVersion = 27")

        # Ensure zero .zip bloat inside android assets
        bloat = [n for n in namelist if n.startswith('android/app/src/main/assets/public/downloads')]
        if bloat:
            raise RuntimeError(f"Unexpected downloads bloat in Android assets: {bloat}")

        print(f"All {len(required_items)} critical Android, workflow & web files verified in archive (minSdkVersion=27).")


if __name__ == '__main__':
    create_project_zip()
