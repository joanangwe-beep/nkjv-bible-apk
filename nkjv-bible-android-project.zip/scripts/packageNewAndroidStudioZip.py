import os
import zipfile

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SRC_PROJECT = os.path.join(ROOT_DIR, "NKJV_BIBLE_ANDROID_NEW")
OUT_DOWNLOADS = os.path.join(ROOT_DIR, "downloads", "NKJV_BIBLE_ANDROID_NEW.zip")

EXCLUDE_DIRS = {".gradle", ".idea", "build", ".cxx", "captures"}
EXCLUDE_FILES = {"local.properties", ".DS_Store"}


def build_zip(dest_path: str) -> tuple[int, int]:
    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    file_count = 0

    with zipfile.ZipFile(dest_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for dirpath, dirnames, filenames in os.walk(SRC_PROJECT):
            dirnames[:] = sorted(d for d in dirnames if d not in EXCLUDE_DIRS)
            for fn in sorted(filenames):
                if fn in EXCLUDE_FILES:
                    continue
                abs_path = os.path.join(dirpath, fn)
                rel_inside = os.path.relpath(abs_path, ROOT_DIR).replace(os.sep, "/")

                info = zipfile.ZipInfo.from_file(abs_path, arcname=rel_inside)
                if fn == "gradlew":
                    info.external_attr = (0o100755 & 0xFFFF) << 16
                else:
                    info.external_attr = (0o100644 & 0xFFFF) << 16

                with open(abs_path, "rb") as f:
                    zf.writestr(info, f.read(), compress_type=zipfile.ZIP_DEFLATED)
                file_count += 1

    with zipfile.ZipFile(dest_path, "r") as zf:
        bad = zf.testzip()
        if bad is not None:
            raise RuntimeError(f"Corrupt ZIP entry detected: {bad}")

    return file_count, os.path.getsize(dest_path)


if __name__ == "__main__":
    if not os.path.isdir(SRC_PROJECT):
        raise SystemExit(f"Source project missing: {SRC_PROJECT}")

    count, size_bytes = build_zip(OUT_DOWNLOADS)
    mb = size_bytes / (1024 * 1024)
    print(f"Packaged NKJV_BIBLE_ANDROID_NEW.zip: {count} files, {size_bytes} bytes ({mb:.2f} MB)")
