/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { runFullAlignmentAudit } from '../src/utils/alignmentAudit';

console.log('===============================================================');
console.log('NKJV BIBLE: COMPREHENSIVE BILINGUAL ALIGNMENT AUDIT');
console.log('Testing all 66 books, Matthew Gospel, stable keys & non-shifting logic');
console.log('===============================================================\n');

const results = runFullAlignmentAudit();
let overallPassed = true;

for (const res of results) {
  const icon = res.passed ? '✓ [PASS]' : '✗ [FAIL]';
  console.log(`${icon} ${res.suiteName} (${res.totalChecks} checks, ${res.failedChecks} failed)`);
  for (const d of res.details) {
    console.log(`    ${d}`);
  }
  console.log('');
  if (!res.passed) overallPassed = false;
}

if (overallPassed) {
  console.log('===============================================================');
  console.log('SUCCESS: All 66 books and alignment suites PASSED with 100% integrity.');
  console.log('===============================================================');
  process.exit(0);
} else {
  console.error('===============================================================');
  console.error('ERROR: One or more audit tests failed.');
  console.error('===============================================================');
  process.exit(1);
}
