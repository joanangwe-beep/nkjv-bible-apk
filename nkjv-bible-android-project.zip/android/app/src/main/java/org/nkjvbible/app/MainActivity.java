package org.nkjvbible.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
